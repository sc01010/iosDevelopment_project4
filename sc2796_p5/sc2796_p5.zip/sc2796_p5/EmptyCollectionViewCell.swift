//
//  EmptyCollectionViewCell.swift
//  sc2796_p5
//
//  Created by Steven Chen on 10/30/21.
//

import UIKit

class EmptyCollectionViewCell: UICollectionViewCell {
    
}
